package com.oxide.cheat;

import android.app.ActivityManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class MemoryReaderService extends Service {

    private static final String TAG        = "OxideReader";
    private static final String TARGET_PKG = "com.catsbit.oxidesurvivalisland";

    /* Кандидаты на основную lib игры (по приоритету) */
    private static final String[] LIB_CANDIDATES = {
        "libil2cpp.so",
        "libgame.so",
        "libUnity.so"
    };

    private int    targetPid   = -1;
    private long   libBase     = 0;
    private long   libSize     = 0;
    private String libName     = "";

    private Thread  readerThread;
    private boolean isRunning = false;

    // ── JNI ─────────────────────────────────────────────────────
    static {
        try {
            System.loadLibrary("oxide_cheat_native");
            Log.i(TAG, "Native library loaded");
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "Native library load failed: " + e.getMessage());
        }
    }

    /** Читает size байт из памяти pid начиная с remoteAddr */
    public native byte[]   readMemoryArray(int pid, long remoteAddr, int size);
    /** Возвращает базу модуля (по имени) в процессе pid */
    public native long     getModuleBase(int pid, String moduleName);
    /** Проверяет ELF magic по адресу в процессе pid */
    public native boolean  isValidELF(int pid, long address);
    /** Разрешает цепочку указателей, возвращает финальный адрес */
    public native long     resolvePointerChain(int pid, long base, int[] offsets);
    /** Совместимость */
    public native int      processVmReadv(int pid, long localAddr, long remoteAddr, int size);
    public native long     getSymbolAddress(String symbol);
    public native String   getProcessInfo(int pid);
    public native void     nativeLog(String message);
    // ── JNI end ──────────────────────────────────────────────────

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!isRunning) {
            isRunning = true;
            startReaderThread();
        }
        return START_STICKY;
    }

    private void startReaderThread() {
        readerThread = new Thread(() -> {
            while (isRunning) {
                try {
                    int pid = getTargetPid();
                    if (pid != -1 && pid != targetPid) {
                        targetPid = pid;
                        Log.i(TAG, "Target PID: " + targetPid);
                        resolveGameLib(pid);
                    }

                    if (targetPid != -1 && libBase != 0) {
                        readGameData();
                    }

                    Thread.sleep(80); // ~12 FPS
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (Exception e) {
                    Log.e(TAG, "Reader loop error: " + e.getMessage());
                }
            }
        }, "oxide-reader");
        readerThread.setDaemon(true);
        readerThread.start();
    }

    // ── Находим PID ──────────────────────────────────────────────

    private int getTargetPid() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return -1;
        for (ActivityManager.RunningAppProcessInfo p : am.getRunningAppProcesses())
            if (TARGET_PKG.equals(p.processName)) return p.pid;
        return -1;
    }

    // ── Поиск базы libil2cpp.so ───────────────────────────────────

    private void resolveGameLib(int pid) {
        libBase = 0;
        libSize = 0;
        libName = "";

        for (String name : LIB_CANDIDATES) {
            long base = getModuleBase(pid, name);
            if (base != 0 && isValidELF(pid, base)) {
                libBase = base;
                libName = name;
                Log.i(TAG, "Game lib: " + name + " @ 0x" + Long.toHexString(base));

                // Логируем /proc/pid/status (TracerPid уже скрыт native-слоем)
                String info = getProcessInfo(pid);
                GameData.addDebugLog("=== process info ===\n" + info);
                return;
            }
        }

        // Fallback: сканируем /proc/<pid>/maps вручную
        libBase = scanMapsForLib(pid);
        if (libBase != 0)
            Log.i(TAG, "Lib found via maps scan @ 0x" + Long.toHexString(libBase));
        else
            Log.e(TAG, "Game lib NOT found for pid " + pid);
    }

    private long scanMapsForLib(int pid) {
        try (BufferedReader br = new BufferedReader(
                new FileReader("/proc/" + pid + "/maps"))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.contains(".so")) continue;
                if (!line.contains("r-xp") && !line.contains("r--p")) continue;

                String[] parts = line.split("\\s+");
                if (parts.length < 2) continue;

                String path = parts[parts.length - 1];
                // Пропускаем стандартные системные либы
                if (path.startsWith("/system/") ||
                    path.startsWith("/apex/")   ||
                    path.startsWith("/vendor/")) continue;

                String[] range = parts[0].split("-");
                if (range.length != 2) continue;

                long base = Long.parseLong(range[0], 16);
                if (isValidELF(pid, base)) {
                    libName = path.substring(path.lastIndexOf('/') + 1);
                    GameData.addDebugLog("Fallback lib: " + libName);
                    return base;
                }
            }
        } catch (IOException e) {
            Log.e(TAG, "maps scan error: " + e.getMessage());
        }
        return 0;
    }

    // ── Основное чтение данных игры ────────────────────────────────

    private void readGameData() {
        /*
         * Структура памяти Oxide (Il2cpp / Unity):
         *
         *  libil2cpp.so
         *   └─ GameManager (синглтон, смещение нужно найти)
         *       ├─ PlayerList  → массив BasePlayer
         *       │    └─ BasePlayer
         *       │         ├─ +0x10  Transform* → position float[3]
         *       │         ├─ +0x20  int   health
         *       │         ├─ +0x24  int   maxHealth
         *       │         └─ +0x30  String* name  (Il2cpp string)
         *       └─ LocalPlayer
         *
         * NOTE: смещения — ПРИМЕРНЫЕ. Обновите через OFFSET_FINDING.md.
         */

        // Пример чтения пула игроков (упрощённо)
        final int  MAX_PLAYERS  = 64;
        final int  PLAYER_STRIDE = 0x100; // размер одного элемента

        // --- читаем блок памяти вокруг либы ---
        int  readSize = 0x2000;
        byte[] buf    = readMemoryArray(targetPid, libBase + 0x1000, readSize);

        if (buf != null && buf.length > 0) {
            parseEntityBuffer(buf, readSize);
            GameData.addDebugLog("Read OK: " + buf.length + " bytes from " + libName);
        } else {
            GameData.addDebugLog("Read returned null (pid=" + targetPid + ")");
        }
    }

    private void parseEntityBuffer(byte[] buf, int len) {
        // Очищаем список
        GameData.clearEntities();

        int entityCount = 0;
        // Ищем структуры с разумными HP (0–500) и валидными float-координатами
        for (int i = 0; i + 0x80 < len; i += 4) {
            int hp = readInt(buf, i + 0x20);
            if (hp <= 0 || hp > 500) continue;

            float x = readFloat(buf, i + 0x10);
            float y = readFloat(buf, i + 0x14);
            float z = readFloat(buf, i + 0x18);

            // Отсекаем мусор: координаты должны быть в разумных пределах
            if (Math.abs(x) > 50000 || Math.abs(y) > 10000 || Math.abs(z) > 50000) continue;
            if (Float.isNaN(x) || Float.isNaN(z)) continue;

            EntityData e = new EntityData();
            e.posX   = x;
            e.posY   = y;
            e.posZ   = z;
            e.health = hp;
            e.name   = "Player";
            GameData.addEntity(e);

            if (++entityCount >= 64) break;
        }

        GameData.addDebugLog("Entities parsed: " + entityCount);
    }

    // ── byte[] helpers ────────────────────────────────────────────

    static float readFloat(byte[] b, int off) {
        return Float.intBitsToFloat(readInt(b, off));
    }

    static int readInt(byte[] b, int off) {
        if (off + 4 > b.length) return 0;
        return (b[off]     & 0xff)        |
               ((b[off+1]  & 0xff) << 8)  |
               ((b[off+2]  & 0xff) << 16) |
               ((b[off+3]  & 0xff) << 24);
    }

    // ── Lifecycle ─────────────────────────────────────────────────

    @Override
    public void onDestroy() {
        isRunning = false;
        if (readerThread != null) readerThread.interrupt();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return new LocalBinder();
    }

    public class LocalBinder extends Binder {
        MemoryReaderService getService() { return MemoryReaderService.this; }
    }
}
