package com.oxide.cheat;

import android.content.ContentResolver;
import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;

import java.lang.reflect.Field;

/**
 * SpoofManager — управляет подменой идентификаторов устройства.
 *
 * Что подменяется:
 *  • ANDROID_ID       (через ContentResolver + Reflection)
 *  • Google Advertising ID (GAID)
 *  • Build.FINGERPRINT, Build.MODEL, Build.MANUFACTURER и т.д.
 *  • Serial number
 *  • Device ID / IMEI
 *
 * ID генерируются нативным кодом один раз при загрузке .so
 * и стабильны в рамках одного запуска.
 */
public class SpoofManager {

    private static final String TAG = "SpoofManager";

    // ── Native methods ──────────────────────────────────────────
    public static native String getAndroidId();
    public static native String getGaid();
    public static native String getSerial();
    public static native String getImei();
    public static native String getDeviceId();
    public static native String getSpoofedBuild();

    private static boolean applied = false;

    // ── Инициализация ───────────────────────────────────────────

    public static void apply(Context ctx) {
        if (applied) return;
        applied = true;

        try {
            spoofBuildFields();
            Log.i(TAG, "Build fields spoofed");
        } catch (Exception e) {
            Log.e(TAG, "Build spoof failed: " + e.getMessage());
        }

        try {
            spoofAndroidId(ctx);
            Log.i(TAG, "AndroidID spoofed: " + getAndroidId());
        } catch (Exception e) {
            Log.e(TAG, "AndroidID spoof failed: " + e.getMessage());
        }

        GameData.addDebugLog("[Spoof] AndroidID : " + getAndroidId());
        GameData.addDebugLog("[Spoof] GAID      : " + getGaid());
        GameData.addDebugLog("[Spoof] Serial    : " + getSerial());
        GameData.addDebugLog("[Spoof] Build     : " + getSpoofedBuild());
    }

    // ── Build fields через Reflection ──────────────────────────

    private static void spoofBuildFields() throws Exception {
        setStaticField(Build.class, "FINGERPRINT",
                "samsung/dm3qxxx/dm3q:14/UP1A.231005.007/S918BXXS3CXA1:user/release-keys");
        setStaticField(Build.class, "MODEL",        "SM-S918B");
        setStaticField(Build.class, "MANUFACTURER", "samsung");
        setStaticField(Build.class, "BRAND",        "samsung");
        setStaticField(Build.class, "DEVICE",       "dm3q");
        setStaticField(Build.class, "PRODUCT",      "dm3qxxx");
        setStaticField(Build.class, "BOARD",        "kalama");
        setStaticField(Build.class, "HARDWARE",     "qcom");
        setStaticField(Build.class, "TAGS",         "release-keys");
        setStaticField(Build.class, "TYPE",         "user");
        setStaticField(Build.class, "HOST",         "SWDD7559");
        setStaticField(Build.class, "ID",           "UP1A.231005.007");
        setStaticField(Build.class, "DISPLAY",      "UP1A.231005.007");

        // Build.SERIAL — подменяем на наш спуфнутый
        setStaticField(Build.class, "SERIAL", getSerial());

        // Build.VERSION
        setStaticField(Build.VERSION.class, "RELEASE",            "14");
        setStaticField(Build.VERSION.class, "SDK_INT",            34);
        setStaticField(Build.VERSION.class, "INCREMENTAL",        "S918BXXS3CXA1");
        setStaticField(Build.VERSION.class, "CODENAME",           "REL");
        setStaticField(Build.VERSION.class, "SECURITY_PATCH",     "2024-01-01");
    }

    // ── ANDROID_ID ─────────────────────────────────────────────
    // Settings.Secure.ANDROID_ID читается через ContentResolver —
    // в этом месте мы не можем патчить на уровне syscall,
    // поэтому используем Reflection на класс Settings.Secure

    private static void spoofAndroidId(Context ctx) throws Exception {
        /*
         * Попытка 1: патчим кэш NameValueCache в Settings.Secure через reflection.
         * Работает на Android 8-13. На 14+ может не работать из-за
         * stronger reflection restrictions, тогда fallback к нативному хуку.
         */
        try {
            Class<?> secureClass = Settings.Secure.class;
            Field cacheField = null;

            // Ищем поле кэша (имя меняется между версиями)
            for (Field f : secureClass.getDeclaredFields()) {
                if (f.getType().getSimpleName().contains("Cache") ||
                    f.getName().contains("cache") ||
                    f.getName().contains("sNameValueCache")) {
                    cacheField = f;
                    break;
                }
            }

            if (cacheField != null) {
                cacheField.setAccessible(true);
                Object cache = cacheField.get(null);
                if (cache != null) {
                    // Ищем Map или HashMap с реальными значениями
                    for (Field cf : cache.getClass().getDeclaredFields()) {
                        cf.setAccessible(true);
                        Object val = cf.get(cache);
                        if (val instanceof java.util.Map) {
                            @SuppressWarnings("unchecked")
                            java.util.Map<String, String> map = (java.util.Map<String, String>) val;
                            map.put(Settings.Secure.ANDROID_ID, getAndroidId());
                            Log.i(TAG, "ANDROID_ID cache patched");
                            return;
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "Cache patch failed, trying provider: " + e.getMessage());
        }

        /*
         * Fallback: ContentProvider URI hook.
         * Не всегда возможен без root, но нативный хук уже
         * перехватывает __system_property_get.
         */
    }

    // ── Reflection helper ───────────────────────────────────────

    private static void setStaticField(Class<?> cls, String name, Object value)
            throws Exception {
        Field f = cls.getDeclaredField(name);
        f.setAccessible(true);

        // Снимаем final modifier
        try {
            Field modifiers = Field.class.getDeclaredField("modifiers");
            modifiers.setAccessible(true);
            modifiers.setInt(f, f.getModifiers() & ~java.lang.reflect.Modifier.FINAL);
        } catch (NoSuchFieldException ignored) {
            // Android 12+ — другой способ
            try {
                Field artField = Field.class.getDeclaredField("artField");
                artField.setAccessible(true);
            } catch (Exception ignored2) { /* best effort */ }
        }

        f.set(null, value);
    }

    // ── Публичные геттеры (для UI) ──────────────────────────────

    public static String getSpoofInfo() {
        return "AndroidID: " + getAndroidId() + "\n" +
               "GAID     : " + getGaid()      + "\n" +
               "Serial   : " + getSerial()    + "\n" +
               "IMEI     : " + getImei()      + "\n" +
               "DeviceID : " + getDeviceId()  + "\n" +
               "Build    : " + getSpoofedBuild();
    }
}
