package com.oxide.cheat;

import android.Manifest;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {

    private static final String TAG        = "OxideCheat";
    private static final String TARGET_PKG = "com.catsbit.oxidesurvivalisland";
    private static final int    PERM_CODE  = 100;
    private static final int    OVERLAY_CODE = 101;

    private TextView    statusText;
    private ToggleButton toggleButton;
    private Button      menuButton;
    private Handler     handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText   = findViewById(R.id.statusText);
        toggleButton = findViewById(R.id.toggleButton);
        menuButton   = findViewById(R.id.menuButton);

        // 1. Применяем bypass сразу при старте
        applySpoofAndBypass();

        // 2. Запрашиваем overlay-разрешение
        requestOverlayPermission();

        // 3. Стандартные разрешения
        requestRuntimePermissions();

        toggleButton.setOnCheckedChangeListener((btn, checked) -> {
            if (checked) {
                if (isTargetRunning()) {
                    startCheatServices();
                    setStatus("RUNNING ✓");
                } else {
                    toggleButton.setChecked(false);
                    setStatus("Game not running!");
                }
            } else {
                stopCheatServices();
                setStatus("STOPPED");
            }
        });

        menuButton.setOnClickListener(v ->
                startActivity(new Intent(this, MenuActivity.class)));

        pollForTarget();
    }

    // ── Применяем все байпасы ────────────────────────────────────

    private void applySpoofAndBypass() {
        try {
            SpoofManager.apply(this);
            LuluBoxBypass.apply(this);

            boolean inVirt = LuluBoxBypass.isRunningInVirtualEnv(this);
            GameData.addDebugLog("[Main] VirtualEnv detected: " + inVirt);
            Log.i(TAG, "Bypass applied. VirtualEnv=" + inVirt);
        } catch (Exception e) {
            Log.e(TAG, "Bypass apply error: " + e.getMessage());
        }
    }

    // ── Overlay permission ───────────────────────────────────────

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, OVERLAY_CODE);
                setStatus("Allow 'Display over apps' permission!");
            }
        }
    }

    private void requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
            }, PERM_CODE);
        }
    }

    // ── Target app polling ───────────────────────────────────────

    private void pollForTarget() {
        handler.post(new Runnable() {
            @Override public void run() {
                if (isTargetRunning()) {
                    setStatus("Target detected — ready");
                    toggleButton.setEnabled(true);
                } else {
                    setStatus("Waiting for Oxide...");
                    toggleButton.setEnabled(false);
                    handler.postDelayed(this, 2000);
                }
            }
        });
    }

    // ── Services ─────────────────────────────────────────────────

    private void startCheatServices() {
        Intent ov  = new Intent(this, OverlayService.class);
        Intent mem = new Intent(this, MemoryReaderService.class);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(ov);
            startForegroundService(mem);
        } else {
            startService(ov);
            startService(mem);
        }
    }

    private void stopCheatServices() {
        stopService(new Intent(this, OverlayService.class));
        stopService(new Intent(this, MemoryReaderService.class));
    }

    private boolean isTargetRunning() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return false;
        for (ActivityManager.RunningAppProcessInfo p : am.getRunningAppProcesses())
            if (TARGET_PKG.equals(p.processName)) return true;
        return false;
    }

    private void setStatus(String msg) {
        statusText.setText("Status: " + msg);
    }
}
