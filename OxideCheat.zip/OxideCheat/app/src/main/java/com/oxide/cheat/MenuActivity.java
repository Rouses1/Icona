package com.oxide.cheat;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {

    private static final String PREFS = "CheatPrefs";

    private CheckBox  espCb, namesCb, boxesCb;
    private SeekBar   rangeSb;
    private TextView  rangeLabel, debugLog, spoofLog;
    private Button    refreshBtn, diagBtn;

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        espCb    = findViewById(R.id.espCheckbox);
        namesCb  = findViewById(R.id.namesCheckbox);
        boxesCb  = findViewById(R.id.boxesCheckbox);
        rangeSb  = findViewById(R.id.espRangeSeekbar);
        rangeLabel = findViewById(R.id.espRangeText);
        debugLog = findViewById(R.id.debugLog);
        spoofLog = findViewById(R.id.spoofLog);
        refreshBtn = findViewById(R.id.debugButton);
        diagBtn  = findViewById(R.id.diagButton);

        loadSettings();

        espCb  .setOnCheckedChangeListener((b,v) -> { GameData.setESPEnabled(v);   save(); });
        namesCb.setOnCheckedChangeListener((b,v) -> { GameData.setNamesEnabled(v); save(); });
        boxesCb.setOnCheckedChangeListener((b,v) -> { GameData.setBoxesEnabled(v); save(); });

        rangeSb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int p, boolean u) {
                int m = p * 10;
                rangeLabel.setText("ESP Range: " + m + "m");
                GameData.setESPRange(m);
                save();
            }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });

        refreshBtn.setOnClickListener(v -> debugLog.setText(GameData.getDebugLog()));

        diagBtn.setOnClickListener(v -> {
            String diag = LuluBoxBypass.getDiagnostics(this);
            spoofLog.setText(diag);
        });

        // Сразу показываем spoof info
        spoofLog.setText(SpoofManager.getSpoofInfo());
    }

    private void loadSettings() {
        espCb  .setChecked(prefs.getBoolean("esp",   true));
        namesCb.setChecked(prefs.getBoolean("names", true));
        boxesCb.setChecked(prefs.getBoolean("boxes", true));
        int r = prefs.getInt("range", 200);
        rangeSb.setProgress(r / 10);
        rangeLabel.setText("ESP Range: " + r + "m");
    }

    private void save() {
        prefs.edit()
            .putBoolean("esp",   espCb.isChecked())
            .putBoolean("names", namesCb.isChecked())
            .putBoolean("boxes", boxesCb.isChecked())
            .putInt("range", (int) GameData.getESPRange())
            .apply();
    }
}
