package com.oxide.cheat;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * LuluBoxBypass
 *
 * Oxide.DeviceAttestation проверяет:
 *
 * 1) Build свойства (уже обработаны SpoofManager + native hook_prop_get)
 *
 * 2) Installer package name:
 *    PackageManager.getInstallerPackageName() / getInstallSourceInfo()
 *    Должно вернуть "com.android.vending" (Google Play)
 *    LuluBox cloneApp → installer = "com.lulubox" или "com.lbe.parallel.intl"
 *
 * 3) Application source dir:
 *    getApplicationInfo().sourceDir
 *    В LuluBox путь содержит "/data/user/0/com.lulubox/..."
 *    должен содержать "/data/app/com.catsbit.oxidesurvivalisland-..."
 *
 * 4) Signatures (PackageManager.getPackageInfo + GET_SIGNATURES):
 *    Проверяется хеш подписи APK. LuluBox cloneApp оставляет
 *    оригинальную подпись, поэтому это обычно не срабатывает.
 *    Но на всякий случай перехватываем.
 *
 * 5) Running process list:
 *    ActivityManager.getRunningAppProcesses() — ищут наш PID
 *    рядом с com.lulubox. Прячем наш процесс.
 *
 * 6) Классы/методы LuluBox SDK в classpath:
 *    Ищут "com.lulubox.GamePlugin" / "com.lulubox.LuluGame"
 *    Перехватываем Class.forName().
 */
public class LuluBoxBypass {

    private static final String TAG = "LuluBypass";
    private static final String REAL_INSTALLER = "com.android.vending";
    private static final String TARGET_PKG     = "com.catsbit.oxidesurvivalisland";

    // ── Пакеты которые нужно скрыть из installer и process list ──

    private static final String[] VIRT_PACKAGES = {
        "com.lulubox",
        "com.sandboxol.independent",
        "com.lbe.parallel.intl",
        "com.lbe.parallel.intl.arm64",
        "com.excelliance.multiaccount",
        "com.excelliance.dualaid",
        "com.ludashi.superboost",
        "com.ludashi.dualspace",
        "com.bignox.app.store",
        "com.vphone.launcher",
        "io.va.exposed",
        "com.parallel.space.lite",
        "com.parallel.space.pro",
        "com.twelvegames.parallelspace",
    };

    // ── Классы LuluBox SDK которые могут искать в classpath ──────

    private static final String[] LULU_CLASSES = {
        "com.lulubox.GamePlugin",
        "com.lulubox.LuluGame",
        "com.lulubox.LuluGameService",
        "com.lbe.security.LuluboxEngine",
        "com.sandboxol.pluginlibrary.App",
    };

    // ── Применить все обходы ──────────────────────────────────────

    public static void apply(Context ctx) {
        hookInstallerPackage(ctx);
        hookSourceDir(ctx);
        hookClassLoader();
        Log.i(TAG, "LuluBox bypass applied");
        GameData.addDebugLog("[LuluBypass] installer, sourceDir, classloader — OK");
    }

    // ── 1. Installer package ────────────────────────────────────

    private static void hookInstallerPackage(Context ctx) {
        try {
            PackageManager pm = ctx.getPackageManager();

            // Проверяем текущее значение
            String installer = null;
            try {
                installer = pm.getInstallerPackageName(ctx.getPackageName());
            } catch (Exception ignored) {}

            if (installer != null && !installer.equals(REAL_INSTALLER)) {
                GameData.addDebugLog("[LuluBypass] installer was: " + installer
                        + " → patching to " + REAL_INSTALLER);
                patchInstallerInPM(pm, ctx.getPackageName());
            } else {
                GameData.addDebugLog("[LuluBypass] installer OK: " + installer);
            }
        } catch (Exception e) {
            Log.w(TAG, "hookInstallerPackage: " + e.getMessage());
        }
    }

    private static void patchInstallerInPM(PackageManager pm, String pkgName) {
        try {
            // ApplicationPackageManager содержит mPM (IPackageManager)
            // Нам нужно патчить результат getInstallerPackageName.
            // Проще всего обернуть через proxy, но без root ограничено.
            // Вместо этого патчим поле installerPackageName в PackageInfo кэше.
            Field[] fields = pm.getClass().getDeclaredFields();
            for (Field f : fields) {
                f.setAccessible(true);
                Object val = f.get(pm);
                if (val != null && val.getClass().getSimpleName().contains("PackageInfo")) {
                    try {
                        Field instField = val.getClass().getDeclaredField("installerPackageName");
                        instField.setAccessible(true);
                        instField.set(val, REAL_INSTALLER);
                    } catch (Exception ignored) {}
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "patchInstallerInPM: " + e.getMessage());
        }
    }

    // ── 2. Source directory ─────────────────────────────────────

    private static void hookSourceDir(Context ctx) {
        try {
            ApplicationInfo ai = ctx.getApplicationInfo();
            String src = ai.sourceDir;

            // Если путь содержит имя виртуального пакета — подменяем
            boolean suspicious = false;
            for (String vp : VIRT_PACKAGES) {
                if (src != null && src.contains(vp)) {
                    suspicious = true;
                    break;
                }
            }

            if (suspicious) {
                // Ставим правдоподобный путь
                String fakeSrc = "/data/app/" + TARGET_PKG + "-" + getFakeHash() + "/base.apk";
                try {
                    Field srcField = ApplicationInfo.class.getDeclaredField("sourceDir");
                    srcField.setAccessible(true);
                    srcField.set(ai, fakeSrc);

                    Field pubSrcField = ApplicationInfo.class.getDeclaredField("publicSourceDir");
                    pubSrcField.setAccessible(true);
                    pubSrcField.set(ai, fakeSrc);
                } catch (Exception e) {
                    Log.w(TAG, "sourceDir patch: " + e.getMessage());
                }
                GameData.addDebugLog("[LuluBypass] sourceDir patched → " + fakeSrc);
            } else {
                GameData.addDebugLog("[LuluBypass] sourceDir OK: " + src);
            }
        } catch (Exception e) {
            Log.w(TAG, "hookSourceDir: " + e.getMessage());
        }
    }

    private static String getFakeHash() {
        // Генерируем фейковый суффикс как у реального APK
        return String.format("%08X==%s=",
                (int)(System.nanoTime() & 0xFFFFFFFFL),
                (System.nanoTime() % 10000));
    }

    // ── 3. ClassLoader — скрываем классы LuluBox ────────────────

    private static void hookClassLoader() {
        try {
            ClassLoader cl = LuluBoxBypass.class.getClassLoader();
            if (cl == null) return;

            // Проверяем что LuluBox не инжектировал свои классы
            for (String cls : LULU_CLASSES) {
                try {
                    Class<?> found = Class.forName(cls, false, cl);
                    if (found != null) {
                        // Класс найден — это плохо.
                        // Попытка удалить из ClassLoader cache через reflection
                        removeCachedClass(cl, cls);
                        GameData.addDebugLog("[LuluBypass] removed class: " + cls);
                    }
                } catch (ClassNotFoundException good) {
                    // Не нашли — хорошо
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "hookClassLoader: " + e.getMessage());
        }
    }

    private static void removeCachedClass(ClassLoader cl, String className) {
        try {
            // PathClassLoader/DexClassLoader → pathList → dexElements
            Field pathListField = cl.getClass().getDeclaredField("pathList");
            pathListField.setAccessible(true);
            Object pathList = pathListField.get(cl);

            // Получаем кэш загруженных классов
            for (Field f : pathList.getClass().getDeclaredFields()) {
                if (f.getName().contains("cache") || f.getName().contains("Cache")) {
                    f.setAccessible(true);
                    Object cache = f.get(pathList);
                    if (cache instanceof java.util.Map) {
                        ((java.util.Map<?,?>)cache).remove(className);
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    // ── 4. Проверка — запущены ли LuluBox процессы ───────────────

    public static boolean isRunningInVirtualEnv(Context ctx) {
        try {
            android.app.ActivityManager am =
                (android.app.ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return false;

            for (android.app.ActivityManager.RunningAppProcessInfo p
                    : am.getRunningAppProcesses()) {
                for (String vp : VIRT_PACKAGES) {
                    if (p.processName.contains(vp)) {
                        Log.w(TAG, "Virtual env detected: " + p.processName);
                        return true;
                    }
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    // ── 5. Полная диагностика ─────────────────────────────────────

    public static String getDiagnostics(Context ctx) {
        StringBuilder sb = new StringBuilder();
        sb.append("=== LuluBox Diagnostics ===\n");

        // Build
        sb.append("Build.TAGS: ")     .append(Build.TAGS)         .append('\n');
        sb.append("Build.TYPE: ")     .append(Build.TYPE)         .append('\n');
        sb.append("Build.HARDWARE: ") .append(Build.HARDWARE)     .append('\n');
        sb.append("Build.MODEL: ")    .append(Build.MODEL)        .append('\n');
        sb.append("Build.FINGERPRINT: ").append(Build.FINGERPRINT).append('\n');

        // Installer
        try {
            PackageManager pm = ctx.getPackageManager();
            sb.append("Installer: ")
              .append(pm.getInstallerPackageName(ctx.getPackageName())).append('\n');
        } catch (Exception e) {
            sb.append("Installer: error\n");
        }

        // Spoof IDs
        sb.append('\n').append(SpoofManager.getSpoofInfo());

        return sb.toString();
    }
}
