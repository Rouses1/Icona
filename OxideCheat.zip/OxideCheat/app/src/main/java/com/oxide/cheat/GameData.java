package com.oxide.cheat;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class GameData {

    private static final List<EntityData> entities = new CopyOnWriteArrayList<>();
    private static final StringBuilder   debugLog  = new StringBuilder();

    // ESP настройки
    private static boolean espEnabled   = true;
    private static boolean namesEnabled = true;
    private static boolean boxesEnabled = true;
    private static int     espRange     = 300; // метры

    // Координаты локального игрока
    private static float playerX, playerY, playerZ;
    private static int   playerHealth = 100;

    // ─────────────────────────────────────────────────────────────

    public static void addEntity(EntityData e) {
        // Вычисляем расстояние до игрока
        e.distance = e.getDistance(playerX, playerY, playerZ);

        if (!espEnabled)               return;
        if (e.distance > espRange)     return;
        if (e.health   <= 0)           return;

        // Конвертируем 3D → 2D
        e.screenX = world2screenX(e.posX, e.posZ);
        e.screenY = world2screenY(e.posY);

        entities.add(e);
    }

    public static void clearEntities() {
        entities.clear();
    }

    public static List<EntityData> getEntities() {
        return new ArrayList<>(entities);
    }

    // ─────────────────────────────────────────────────────────────
    // Простая орто-проекция (заменить на матрицу камеры для точности)
    // ─────────────────────────────────────────────────────────────

    private static float world2screenX(float wx, float wz) {
        final float W = 1080f;
        float dx = wx - playerX;
        float dz = wz - playerZ;
        float angle = (float) Math.atan2(dx, dz);
        return W / 2f + angle * 180f;
    }

    private static float world2screenY(float wy) {
        final float H = 2400f;
        return H / 2f - (wy - playerY) * 6f;
    }

    // ─────────────────────────────────────────────────────────────

    public static void setPlayerPos(float x, float y, float z) {
        playerX = x; playerY = y; playerZ = z;
    }

    public static void setPlayerHealth(int hp) { playerHealth = hp; }

    public static float getPlayerX()  { return playerX; }
    public static float getPlayerY()  { return playerY; }
    public static float getPlayerZ()  { return playerZ; }
    public static int   getPlayerHealth() { return playerHealth; }

    // ─────────────────────────────────────────────────────────────

    public static void setESPEnabled  (boolean v) { espEnabled   = v; }
    public static void setNamesEnabled(boolean v) { namesEnabled = v; }
    public static void setBoxesEnabled(boolean v) { boxesEnabled = v; }
    public static void setESPRange    (int     v) { espRange     = v; }

    public static boolean isESPEnabled  () { return espEnabled;   }
    public static boolean isNamesEnabled() { return namesEnabled; }
    public static boolean isBoxesEnabled() { return boxesEnabled; }
    public static float   getESPRange   () { return espRange;     }

    // ─────────────────────────────────────────────────────────────

    public static void addDebugLog(String msg) {
        synchronized (debugLog) {
            debugLog.append(msg).append('\n');
            if (debugLog.length() > 8000)
                debugLog.delete(0, debugLog.length() - 4000);
        }
    }

    public static String getDebugLog() {
        synchronized (debugLog) { return debugLog.toString(); }
    }

    public static void clearDebugLog() {
        synchronized (debugLog) { debugLog.setLength(0); }
    }
}
