package com.oxide.cheat;

public class EntityData {
    public int id;
    public float posX;
    public float posY;
    public float posZ;
    public int health;
    public String name;
    public int type; // 0=player, 1=npc, 2=resource, etc
    
    // Экран координаты для отрисовки
    public float screenX;
    public float screenY;
    
    // Дополнительные данные
    public float armor;
    public int level;
    public boolean isAlive;
    public float distance;

    public EntityData() {
        this.id = 0;
        this.posX = 0;
        this.posY = 0;
        this.posZ = 0;
        this.health = 0;
        this.name = "";
        this.type = 0;
        this.screenX = 0;
        this.screenY = 0;
        this.armor = 0;
        this.level = 0;
        this.isAlive = true;
        this.distance = 0;
    }

    @Override
    public String toString() {
        return "EntityData{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", pos=(" + posX + "," + posY + "," + posZ + ")" +
                ", health=" + health +
                ", type=" + type +
                ", distance=" + distance +
                '}';
    }

    public float getDistance(float playerX, float playerY, float playerZ) {
        float dx = posX - playerX;
        float dy = posY - playerY;
        float dz = posZ - playerZ;
        distance = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        return distance;
    }
}
