package com.oxide.cheat;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

public class OverlayService extends Service {

    private static final String TAG = "OverlayService";
    private WindowManager windowManager;
    private OverlayView overlayView;
    private WindowManager.LayoutParams params;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "OverlayService started");
        
        if (overlayView == null) {
            createOverlay();
        }
        
        return START_STICKY;
    }

    private void createOverlay() {
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        overlayView = new OverlayView(this);

        int type;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            type = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        }

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                -1
        );

        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 0;
        params.y = 0;

        windowManager.addView(overlayView, params);
        Log.d(TAG, "Overlay created");
    }

    @Override
    public void onDestroy() {
        if (overlayView != null) {
            windowManager.removeView(overlayView);
        }
        Log.d(TAG, "OverlayService destroyed");
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public static class OverlayView extends View {

        private Paint statusPaint;
        private Paint espPaint;
        private Paint textPaint;
        private boolean isWorking = true;
        private static final int UPDATE_INTERVAL = 50; // 20 FPS

        public OverlayView(Context context) {
            super(context);
            setWillNotDraw(false);
            initPaints();
            startUpdateThread();
        }

        private void initPaints() {
            // Зеленый индикатор работы
            statusPaint = new Paint();
            statusPaint.setColor(Color.GREEN);
            statusPaint.setStyle(Paint.Style.FILL);
            statusPaint.setAntiAlias(true);

            // Краска для ESP
            espPaint = new Paint();
            espPaint.setColor(Color.GREEN);
            espPaint.setStrokeWidth(2);
            espPaint.setStyle(Paint.Style.STROKE);
            espPaint.setAntiAlias(true);

            // Краска для текста
            textPaint = new Paint();
            textPaint.setColor(Color.GREEN);
            textPaint.setTextSize(14);
            textPaint.setAntiAlias(true);
        }

        private void startUpdateThread() {
            new Thread(() -> {
                while (isWorking) {
                    try {
                        Thread.sleep(UPDATE_INTERVAL);
                        post(this::invalidate);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }).start();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            // Рисуем зеленый индикатор в углу
            canvas.drawCircle(50, 50, 15, statusPaint);

            // Рисуем текст статуса
            canvas.drawText("WORKING", 75, 55, textPaint);

            // Получаем данные из GameData и рисуем ESP
            drawESP(canvas);
        }

        private void drawESP(Canvas canvas) {
            // Получаем список врагов из GameData
            for (EntityData entity : GameData.getEntities()) {
                // Конвертируем 3D позицию в 2D экран
                // Это упрощенная версия - реальная нужна матрица вида и проекции
                
                float screenX = entity.screenX;
                float screenY = entity.screenY;

                if (screenX > 0 && screenY > 0 && 
                    screenX < getWidth() && screenY < getHeight()) {
                    
                    // Рисуем бокс
                    float boxSize = 50;
                    canvas.drawRect(
                            screenX - boxSize/2,
                            screenY - boxSize,
                            screenX + boxSize/2,
                            screenY,
                            espPaint
                    );

                    // Рисуем имя и HP
                    if (entity.name != null) {
                        canvas.drawText(entity.name, screenX - 20, screenY + 20, textPaint);
                    }
                    if (entity.health > 0) {
                        canvas.drawText("HP: " + entity.health, screenX - 20, screenY + 40, textPaint);
                    }

                    // Рисуем линию до врага (Line of sight)
                    canvas.drawLine(
                            getWidth() / 2f,
                            getHeight() / 2f,
                            screenX,
                            screenY,
                            espPaint
                    );
                }
            }
        }
    }
}
