package com.oxide.cheat;

/**
 * Структуры данных Oxide Survival Island
 * Основано на Il2cpp дампе и reverse engineering
 * 
 * ВАЖНО: Смещения (offsets) нужно уточнить через анализ дампа!
 */
public class OxideStructures {

    /**
     * Структура для хранения информации об игроке
     * 
     * Размер: ~0x200 байт
     */
    public static class PlayerData {
        // Позиция в мире
        public float posX;      // offset 0x10
        public float posY;      // offset 0x14
        public float posZ;      // offset 0x18
        
        // Здоровье и броня
        public int health;      // offset 0x20
        public int maxHealth;   // offset 0x24
        public float armor;     // offset 0x28
        
        // Информация об игроке
        public int playerId;    // offset 0x00
        public String name;     // offset 0x30 (32 bytes)
        public int level;       // offset 0x50
        
        // Оружие и инвентарь
        public int weaponId;    // offset 0x54
        public int ammo;        // offset 0x58
        
        // Состояние
        public boolean isAlive; // offset 0x5C
        public int team;        // offset 0x60
        
        // Угол поворота
        public float rotationY; // offset 0x64
        
        // Скорость движения
        public float velocityX; // offset 0x68
        public float velocityY; // offset 0x6C
        public float velocityZ; // offset 0x70
    }

    /**
     * Структура сущности в мире
     * Враги, NPC, предметы
     * 
     * Размер: ~0x80 байт
     */
    public static class EntityData {
        // Идентификация
        public int entityId;    // offset 0x00
        public int type;        // offset 0x04 (0=player, 1=npc, 2=resource, 3=structure)
        public int subType;     // offset 0x08
        
        // Позиция
        public float posX;      // offset 0x10
        public float posY;      // offset 0x14
        public float posZ;      // offset 0x18
        
        // Угол
        public float rotation;  // offset 0x1C
        
        // Здоровье
        public int health;      // offset 0x20
        public int maxHealth;   // offset 0x24
        
        // Скорость и статус
        public float speed;     // offset 0x28
        public int state;       // offset 0x2C (0=idle, 1=moving, 2=attacking)
        
        // Информация
        public String name;     // offset 0x30 (32 bytes)
        public int ownerUid;    // offset 0x50 - UID владельца
        
        // Броня для нпс/врагов
        public float armor;     // offset 0x54
        
        // Видимость
        public boolean isVisible; // offset 0x5C
        public int lastSeen;    // offset 0x60
        
        // Расстояние до игрока
        public float distance;  // вычисляется, не в памяти
    }

    /**
     * Структура ресурса/предмета на земле
     * 
     * Размер: ~0x60 байт
     */
    public static class ItemData {
        // Идентификация
        public int itemId;      // offset 0x00
        public int itemType;    // offset 0x04 (0=ore, 1=wood, 2=cloth, 3=food)
        public int quantity;    // offset 0x08
        
        // Позиция
        public float posX;      // offset 0x10
        public float posY;      // offset 0x14
        public float posZ;      // offset 0x18
        
        // Информация
        public String itemName; // offset 0x20 (32 bytes)
        public int rarity;      // offset 0x40 (0=common, 1=rare, 2=epic, 3=legendary)
        
        // Видимость и состояние
        public boolean canPickup; // offset 0x44
        public float spawnTime; // offset 0x48
    }

    /**
     * Основная структура World/GameManager
     * Здесь хранятся указатели на списки врагов, предметов и т.д.
     * 
     * Нужна тщательная reverse engineering!
     */
    public static class WorldData {
        // Указатели на списки
        public long playerListPtr;      // offset ??? - указатель на массив Player
        public long entityListPtr;      // offset ??? - указатель на массив Entity
        public long itemListPtr;        // offset ??? - указатель на массив Item
        
        // Счетчики
        public int playerCount;         // offset ???
        public int entityCount;         // offset ???
        public int itemCount;           // offset ???
        
        // Состояние игры
        public int gameState;           // offset ??? (0=menu, 1=loading, 2=playing)
        public int currentTime;         // offset ???
        
        // Позиция камеры
        public float cameraPosX;        // offset ???
        public float cameraPosY;        // offset ???
        public float cameraPosZ;        // offset ???
    }

    /**
     * Структура скелета для кастомизации и нанесения урона
     * 
     * Используется для рейкаста и целеприцела
     */
    public static class BoneData {
        // Основные кости
        public static final int HEAD = 0;
        public static final int CHEST = 1;
        public static final int PELVIS = 2;
        public static final int LEFT_ARM = 3;
        public static final int RIGHT_ARM = 4;
        public static final int LEFT_LEG = 5;
        public static final int RIGHT_LEG = 6;
        
        // Координаты костей в мире
        public float posX;
        public float posY;
        public float posZ;
    }

    /**
     * Смещения в памяти libil2cpp.so
     * ВНИМАНИЕ: Эти значения требуют уточнения!
     * 
     * Используйте при сканировании памяти через процесс_vm_readv
     */
    public static class Offsets {
        // Глобальные указатели
        public static final long WORLD_DATA_PTR = 0x001234BC; // нужно найти!
        public static final long PLAYER_PTR = 0x00567890;     // нужно найти!
        
        // Внутри Player структуры
        public static final int PLAYER_POS_OFFSET = 0x10;
        public static final int PLAYER_HEALTH_OFFSET = 0x20;
        public static final int PLAYER_NAME_OFFSET = 0x30;
        
        // Внутри Entity структуры
        public static final int ENTITY_POS_OFFSET = 0x10;
        public static final int ENTITY_HEALTH_OFFSET = 0x20;
        public static final int ENTITY_TYPE_OFFSET = 0x04;
        
        // Размеры структур
        public static final int PLAYER_SIZE = 0x200;
        public static final int ENTITY_SIZE = 0x80;
        public static final int ITEM_SIZE = 0x60;
        
        // Максимальные количества
        public static final int MAX_PLAYERS = 128;
        public static final int MAX_ENTITIES = 1024;
        public static final int MAX_ITEMS = 2048;
    }

    /**
     * Парсер Il2cpp строк
     * Il2cpp может хранить строки как указатели на данные в памяти
     */
    public static class Il2CppString {
        // Структура Il2cpp строки
        // offset 0x00: длина
        // offset 0x04: данные (может быть указателем или встроенными данными)
        
        public static String readString(byte[] data, int offset, int maxLen) {
            try {
                // Читаем длину
                int len = 0;
                if (offset + 4 <= data.length) {
                    len = bytesToInt(data, offset + 4);
                }
                
                if (len > maxLen) len = maxLen;
                if (offset + len > data.length) len = data.length - offset;
                
                byte[] strBytes = new byte[len];
                System.arraycopy(data, offset + 8, strBytes, 0, len);
                
                // Находим нулевой терминатор
                int actualLen = 0;
                for (byte b : strBytes) {
                    if (b == 0) break;
                    actualLen++;
                }
                
                return new String(strBytes, 0, actualLen);
            } catch (Exception e) {
                return "";
            }
        }
        
        private static int bytesToInt(byte[] data, int offset) {
            if (offset + 4 > data.length) return 0;
            return (data[offset] & 0xff) |
                   ((data[offset + 1] & 0xff) << 8) |
                   ((data[offset + 2] & 0xff) << 16) |
                   ((data[offset + 3] & 0xff) << 24);
        }
    }

    /**
     * Вспомогательный класс для поиска смещений
     * используется при первом запуске для auto-detection структур
     */
    public static class OffsetFinder {
        /**
         * Ищет сигнатуру в памяти
         * Например поиск "GOLD_AMOUNT" или других строк
         */
        public static long findSignature(byte[] data, String signature) {
            byte[] sigBytes = signature.getBytes();
            for (int i = 0; i < data.length - sigBytes.length; i++) {
                boolean found = true;
                for (int j = 0; j < sigBytes.length; j++) {
                    if (data[i + j] != sigBytes[j]) {
                        found = false;
                        break;
                    }
                }
                if (found) return i;
            }
            return -1;
        }
        
        /**
         * Ищет последовательность байт (pattern scan)
         */
        public static long findPattern(byte[] data, String pattern) {
            // pattern формата: "48 8B 45 E8 48 8D 0D ?? ?? ?? ??"
            // где ?? это wildcards (любой байт)
            
            String[] parts = pattern.split(" ");
            byte[] patternBytes = new byte[parts.length];
            byte[] patternMask = new byte[parts.length];
            
            for (int i = 0; i < parts.length; i++) {
                if (parts[i].equals("??")) {
                    patternMask[i] = 0;
                    patternBytes[i] = 0;
                } else {
                    patternMask[i] = (byte) 0xFF;
                    patternBytes[i] = (byte) Integer.parseInt(parts[i], 16);
                }
            }
            
            for (int i = 0; i < data.length - patternBytes.length; i++) {
                boolean found = true;
                for (int j = 0; j < patternBytes.length; j++) {
                    if ((data[i + j] & patternMask[j]) != (patternBytes[j] & patternMask[j])) {
                        found = false;
                        break;
                    }
                }
                if (found) return i;
            }
            return -1;
        }
    }
}
