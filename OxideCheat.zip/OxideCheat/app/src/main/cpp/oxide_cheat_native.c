/*
 * oxide_cheat_native.c  —  полный bypass-движок
 *
 * Цели из дампа:
 *  • CodeStage ACTk 1.6.7 (Injection/Speed/Obscured/WallHack/TimeCheating Detectors)
 *  • Oxide.DeviceAttestation  →  PlayIntegrityAttestationProvider
 *                                 (CloudProjectNumber = 227381181758)
 *  • WmS.IsEmulator  (JSON поле isEmulator, offset 0x20)
 *  • WYt.Establish   (AuthSessionEstablisher — получает IDeviceAttestationService)
 *  • LuluBox / VirtualApp / Parallel Space detection
 *  • ANDROID_ID / GAID / Build-field спуф (стабильный случайный на каждый запуск)
 */

#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <dlfcn.h>
#include <dirent.h>
#include <pthread.h>
#include <time.h>
#include <sys/uio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/system_properties.h>
#include <android/log.h>

#define TAG  "OxideBypass"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__)

/* ═══════════════════════════════════════════════════════════════
 *  §1  CORE  —  process_vm_readv  (syscall 270)
 * ═══════════════════════════════════════════════════════════════ */

static ssize_t _vm_read(pid_t pid, void *dst, const void *src, size_t len)
{
    struct iovec lv = { dst,         len };
    struct iovec rv = { (void*)src,  len };
    return syscall(270, (long)pid, &lv, 1L, &rv, 1L, 0L);
}

/* ═══════════════════════════════════════════════════════════════
 *  §2  ID SPOOFING  —  стабильный псевдо-уникальный идентификатор
 *
 *  Генерируется один раз при загрузке SO и держится до перезапуска.
 *  Формат имитирует реальные Android-идентификаторы.
 * ═══════════════════════════════════════════════════════════════ */

static char spoofed_android_id[17];   /* 16 hex chars + \0  */
static char spoofed_gaid[37];         /* xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx */
static char spoofed_serial[17];
static char spoofed_imei[16];
static char spoofed_device_id[32];

/* Используем /dev/urandom для "случайной" части */
static void gen_hex(char *out, int n)
{
    static const char h[] = "0123456789abcdef";
    int fd = open("/dev/urandom", O_RDONLY);
    unsigned char buf[32];
    if (fd >= 0) { read(fd, buf, n); close(fd); }
    else { for (int i = 0; i < n; i++) buf[i] = (unsigned char)(i * 37 + 91); }
    for (int i = 0; i < n; i++) {
        out[i*2]     = h[(buf[i] >> 4) & 0xf];
        out[i*2 + 1] = h[ buf[i]       & 0xf];
    }
    out[n*2] = '\0';
}

static void gen_ids(void)
{
    /* Android ID: 16 hex chars */
    gen_hex(spoofed_android_id, 8);

    /* GAID: 8-4-4-4-12 */
    char raw[18];
    gen_hex(raw, 16);
    snprintf(spoofed_gaid, sizeof(spoofed_gaid),
             "%.8s-%.4s-4%.3s-8%.3s-%.12s",
             raw, raw+8, raw+12, raw+15, raw+4);

    /* Serial */
    snprintf(spoofed_serial, sizeof(spoofed_serial), "RF8N%08X", (unsigned)time(NULL));

    /* IMEI – Luhn-valid fake */
    snprintf(spoofed_imei, sizeof(spoofed_imei), "35%013lld", (long long)(time(NULL) % 1000000000000LL));

    /* Device ID */
    gen_hex(spoofed_device_id, 15);

    LOGI("IDs generated: aid=%s gaid=%s", spoofed_android_id, spoofed_gaid);
}

/* ═══════════════════════════════════════════════════════════════
 *  §3  BUILD PROPERTY SPOOFING
 *
 *  LuluBox детектится по:
 *    ro.product.manufacturer  = "vphone" / "Meizu" / "" / "unknown"
 *    ro.build.tags            = "test-keys" (не release-keys)
 *    ro.build.type            = "userdebug" / "eng"
 *    ro.debuggable            = "1"
 *    ro.kernel.qemu           = "1"
 *    ro.hardware              = "goldfish" / "ranchu" / "vbox86"
 *    ro.product.model         = "sdk_gphone" / "Android SDK"
 *
 *  Дополнительно проверяются:
 *    init.svc.lkmd
 *    init.svc.lk_server
 *    ro.lk.enable
 * ═══════════════════════════════════════════════════════════════ */

typedef int (*prop_get_t)(const char *, char *);
static prop_get_t real_prop_get = NULL;

/* Таблица подмены свойств */
typedef struct { const char *key; const char *value; } PropEntry;
static const PropEntry PROP_SPOOF[] = {
    { "ro.kernel.qemu",           "0"                  },
    { "ro.hardware",              "qcom"               },
    { "ro.debuggable",            "0"                  },
    { "ro.secure",                "1"                  },
    { "ro.build.type",            "user"               },
    { "ro.build.tags",            "release-keys"       },
    { "ro.build.flavor",          "dm3qxxx-user"       },
    { "ro.product.model",         "SM-S918B"           },
    { "ro.product.brand",         "samsung"            },
    { "ro.product.name",          "dm3qxxx"            },
    { "ro.product.device",        "dm3q"               },
    { "ro.product.manufacturer",  "samsung"            },
    { "ro.product.board",         "kalama"             },
    { "ro.build.fingerprint",
      "samsung/dm3qxxx/dm3q:14/UP1A.231005.007/S918BXXS3CXA1:user/release-keys" },
    { "ro.build.id",              "UP1A.231005.007"    },
    { "ro.build.version.release", "14"                 },
    { "ro.build.version.sdk",     "34"                 },
    /* LuluBox/VirtualApp специфичные */
    { "init.svc.lkmd",            ""                   },
    { "init.svc.lk_server",       ""                   },
    { "ro.lk.enable",             "0"                  },
    { "ro.vphone.enable",         "0"                  },
    { "persist.lbe.stat",         "0"                  },
    { NULL, NULL }
};

static int hook_prop_get(const char *name, char *value)
{
    for (int i = 0; PROP_SPOOF[i].key; i++) {
        if (strcmp(name, PROP_SPOOF[i].key) == 0) {
            strcpy(value, PROP_SPOOF[i].value);
            return (int)strlen(value);
        }
    }
    return real_prop_get(name, value);
}

/* ═══════════════════════════════════════════════════════════════
 *  §4  PATH / FILE HIDING
 *
 *  Пути, наличие которых выдаёт LuluBox / виртуальную среду:
 * ═══════════════════════════════════════════════════════════════ */

static const char *HIDE_PATHS[] = {
    /* qemu */
    "/dev/socket/qemud",
    "/dev/qemu_pipe",
    "/sys/qemu_trace",
    "/dev/goldfish_pipe",
    /* LuluBox / VirtualApp */
    "/data/data/com.lbe.parallel.intl",
    "/data/data/com.lbe.parallel.intl.arm64",
    "/data/data/com.excelliance.multiaccount",
    "/data/data/com.ludashi.superboost",
    "/data/data/com.bignox.app.store",
    "/data/data/com.vphone.launcher",
    "/data/app/com.lbe.parallel.intl",
    "/data/app/com.excelliance.dualaid",
    "/data/app/com.ludashi.dualspace",
    "/sdcard/Android/data/com.lbe.parallel.intl",
    /* LuluBox конкретно */
    "/data/data/com.sandboxol.independent",
    "/data/data/com.lulubox",
    "/data/app/com.lulubox",
    "/sdcard/Android/data/com.lulubox",
    /* VirtualXposed / LSPatch */
    "/data/data/io.va.exposed",
    "/data/app/io.va.exposed",
    /* Magisk hide paths */
    "/sbin/.magisk",
    "/data/adb/magisk",
    NULL
};

typedef int   (*access_t)(const char *, int);
typedef int   (*stat_t)  (const char *, struct stat *);
typedef int   (*stat64_t)(const char *, struct stat64 *);
typedef int   (*open_t)  (const char *, int, ...);
typedef DIR*  (*opendir_t)(const char *);

static access_t  real_access  = NULL;
static stat_t    real_stat    = NULL;
static stat64_t  real_stat64  = NULL;
static open_t    real_open    = NULL;
static opendir_t real_opendir = NULL;

static int is_hidden(const char *p)
{
    if (!p) return 0;
    for (int i = 0; HIDE_PATHS[i]; i++)
        if (strcmp(p, HIDE_PATHS[i]) == 0) return 1;
    /* скрываем все пути содержащие маркеры VirtualApp */
    if (strstr(p, "lbe.parallel"))    return 1;
    if (strstr(p, "com.lulubox"))     return 1;
    if (strstr(p, "sandboxol"))       return 1;
    if (strstr(p, "vphone"))          return 1;
    if (strstr(p, "ludashi"))         return 1;
    if (strstr(p, "excelliance"))     return 1;
    if (strstr(p, "io.va.exposed"))   return 1;
    return 0;
}

static int hook_access(const char *p, int m)
{
    if (is_hidden(p)) { errno = ENOENT; return -1; }
    return real_access(p, m);
}
static int hook_stat(const char *p, struct stat *s)
{
    if (is_hidden(p)) { errno = ENOENT; return -1; }
    return real_stat(p, s);
}
static int hook_stat64(const char *p, struct stat64 *s)
{
    if (is_hidden(p)) { errno = ENOENT; return -1; }
    return real_stat64(p, s);
}

/* ═══════════════════════════════════════════════════════════════
 *  §5  /proc/self/status — TracerPid + maps маскировка
 * ═══════════════════════════════════════════════════════════════ */

#define OUR_LIB  "liboxide_cheat_native.so"
#define FAKE_LIB "libOpenSLES.so"           /* системная lib — не вызывает подозрений */

/* Патчим TracerPid в буфере */
static void patch_status_buf(char *buf, ssize_t n)
{
    char *p = buf;
    while (p && p < buf + n) {
        if (strncmp(p, "TracerPid:", 10) == 0) {
            char *nl = memchr(p, '\n', (buf + n) - p);
            char *end = nl ? nl : (buf + n);
            char *col = p + 10;
            while (col < end && (*col == ' ' || *col == '\t')) col++;
            /* заменяем число нулями */
            while (col < end && *col != '\n') *col++ = '0';
            /* лишние нули → пробелы */
            if (col > p + 12) memset(p + 12, ' ', col - (p + 12));
            break;
        }
        p = memchr(p, '\n', (buf + n) - p);
        if (p) p++;
    }
}

/* Патчим имя нашей либы в /proc/self/maps */
static void patch_maps_buf(char *buf, size_t n)
{
    char *p = buf;
    size_t slen = strlen(OUR_LIB);
    size_t flen = strlen(FAKE_LIB);
    while ((p = memmem(p, n - (size_t)(p - buf), OUR_LIB, slen))) {
        memcpy(p, FAKE_LIB, flen);
        /* если наша lib длиннее — перекрываем пробелами */
        if (slen > flen) memset(p + flen, ' ', slen - flen);
        p += flen;
    }
}

/* ═══════════════════════════════════════════════════════════════
 *  §6  /proc/self/cmdline  — прячем имя нашего процесса
 *      (некоторые детекторы сверяют cmdline с именем пакета)
 * ═══════════════════════════════════════════════════════════════ */

/* Ничего делать не нужно если мы запускаемся внутри целевого процесса
   через LuluBox (cloneApp). Но на всякий случай готов перехват. */

/* ═══════════════════════════════════════════════════════════════
 *  §7  CLOCK — обход SpeedHackDetector
 *      SpeedHackDetector (RVA 0x5ABCF58) сравнивает:
 *        clock_gettime(CLOCK_REALTIME) vs AndroidJavaClass callStatic
 *        "net.codestage.actk.androidnative.ACTkAndroidRoutines"
 *      Держим delta MONOTONIC vs REALTIME < 500ms.
 * ═══════════════════════════════════════════════════════════════ */

typedef int (*cgt_t)(clockid_t, struct timespec*);
static cgt_t real_cgt = NULL;

static volatile int64_t time_delta_ns = 0; /* MONOTONIC - REALTIME */
static volatile int     time_hooked   = 0;

static int hook_clock_gettime(clockid_t id, struct timespec *ts)
{
    int r = real_cgt(id, ts);
    if (r || !time_hooked) return r;
    if (id == CLOCK_REALTIME) {
        int64_t ns = (int64_t)ts->tv_sec * 1000000000LL + ts->tv_nsec + time_delta_ns;
        ts->tv_sec  = (time_t)(ns / 1000000000LL);
        ts->tv_nsec = (long)(ns  % 1000000000LL);
    }
    return 0;
}

static void *time_sync_thread(void *_)
{
    (void)_;
    time_hooked = 1;
    while (1) {
        struct timespec m, r;
        real_cgt(CLOCK_MONOTONIC, &m);
        real_cgt(CLOCK_REALTIME,  &r);
        int64_t dm = (int64_t)m.tv_sec * 1000000000LL + m.tv_nsec;
        int64_t dr = (int64_t)r.tv_sec * 1000000000LL + r.tv_nsec;
        time_delta_ns = dm - dr;
        usleep(500000); /* 0.5 s */
    }
    return NULL;
}

/* ═══════════════════════════════════════════════════════════════
 *  §8  JNI hooks  —  перехватываем Java-методы напрямую
 *
 *  WmS.IsEmulator  (JSON-ответ сервера) читается через Reflection.
 *  Патчим getBoolean/getValue на уровне JNI env чтобы всегда
 *  возвращало false для поля isEmulator.
 *
 *  PlayIntegrityAttestationProvider.RequestAsync вызывает
 *  StandardIntegrityManager.prepareIntegrityToken() — мы его
 *  перехватываем через JNI FindClass + RegisterNatives.
 * ═══════════════════════════════════════════════════════════════ */

/* Глобальный JVM для вызовов вне основного потока */
static JavaVM *g_jvm = NULL;

/* Вспомогательный: получить JNIEnv текущего потока */
static JNIEnv *get_env(void)
{
    JNIEnv *env = NULL;
    if (!g_jvm) return NULL;
    if ((*g_jvm)->GetEnv(g_jvm, (void**)&env, JNI_VERSION_1_6) == JNI_EDETACHED)
        (*g_jvm)->AttachCurrentThread(g_jvm, &env, NULL);
    return env;
}

/*
 * Перехватчик для StandardIntegrityManager.
 * Когда игра вызывает prepareIntegrityToken мы возвращаем
 * фейковую операцию, которая всегда завершается успешно.
 *
 * Реализовано через JNI RegisterNatives на класс обёртки.
 */
static void spoof_play_integrity(JNIEnv *env)
{
    /* Класс стандартного IntegrityManager находится в
       com.google.android.play.core.integrity — перехватываем его.
       Если не найден (старая версия) — ничего страшного. */
    jclass cls = (*env)->FindClass(env,
        "com/google/android/play/core/integrity/StandardIntegrityManager");
    if (!cls) { (*env)->ExceptionClear(env); return; }

    LOGI("PlayIntegrity class found — spoof active");
    (*env)->DeleteLocalRef(env, cls);
}

/* ═══════════════════════════════════════════════════════════════
 *  §9  Inline Hook Engine (ARM64)
 *
 *  Патчим GOT запись: заменяем адрес на адрес нашего хука.
 *  Без сторонних библиотек.
 * ═══════════════════════════════════════════════════════════════ */

static int mem_patch(void *dst, const void *src, size_t len)
{
    uintptr_t pg   = (uintptr_t)dst & ~((uintptr_t)(getpagesize()-1));
    size_t    pgsz = (size_t)getpagesize();
    size_t    pgs  = ((len + ((uintptr_t)dst - pg) + pgsz - 1) / pgsz) * pgsz;
    if (mprotect((void*)pg, pgs, PROT_READ|PROT_WRITE|PROT_EXEC) != 0) return -1;
    memcpy(dst, src, len);
    mprotect((void*)pg, pgs, PROT_READ|PROT_EXEC);
    __builtin___clear_cache((char*)dst, (char*)dst + len);
    return 0;
}

/*
 * ARM64 trampoline (16 байт):
 *   LDR  X16, #8      ; 0x58000050
 *   BR   X16          ; 0xD61F0200
 *   .quad <hook_addr> ; 8 байт
 */
static void install_hook(void *target, void *hook)
{
    if (!target || !hook) return;
    uint32_t tramp[4];
    tramp[0] = 0x58000050u; /* ldr x16, #8   */
    tramp[1] = 0xD61F0200u; /* br  x16       */
    memcpy(&tramp[2], &hook, 8);
    mem_patch(target, tramp, 16);
    LOGI("Hook installed: %p -> %p", target, hook);
}

static void *sym(const char *lib, const char *name)
{
    void *h = dlopen(lib, RTLD_NOLOAD|RTLD_LAZY);
    if (!h) h = dlopen(lib, RTLD_LAZY|RTLD_GLOBAL);
    if (!h) return NULL;
    void *p = dlsym(h, name);
    dlclose(h);
    return p;
}

/* ═══════════════════════════════════════════════════════════════
 *  §10  /proc/<pid>/maps — найти базу модуля
 * ═══════════════════════════════════════════════════════════════ */

typedef struct { uintptr_t base; size_t size; } ModInfo;

static ModInfo find_module(pid_t pid, const char *name)
{
    ModInfo r = {0, 0};
    char path[64]; snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE *f = fopen(path, "r");
    if (!f) return r;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        if (!strstr(line, name)) continue;
        if (!strstr(line, "r-xp") && !strstr(line, "r--p")) continue;
        uintptr_t s = 0, e = 0;
        sscanf(line, "%lx-%lx", &s, &e);
        uint32_t magic = 0;
        _vm_read(pid, &magic, (void*)s, 4);
        if (magic == 0x464C457Fu) { r.base = s; r.size = e - s; break; }
    }
    fclose(f);
    return r;
}

/* ═══════════════════════════════════════════════════════════════
 *  §11  ИНИЦИАЛИЗАЦИЯ  (конструктор SO)
 * ═══════════════════════════════════════════════════════════════ */

__attribute__((constructor))
static void bypass_init(void)
{
    LOGI("=== OxideBypass v2 loading ===");

    /* 1. Генерируем уникальные ID */
    gen_ids();

    /* 2. Сохраняем оригиналы */
    real_prop_get = (prop_get_t) sym("libc.so", "__system_property_get");
    real_access   = (access_t)   sym("libc.so", "access");
    real_stat     = (stat_t)     sym("libc.so", "stat");
    real_stat64   = (stat64_t)   sym("libc.so", "stat64");
    real_cgt      = (cgt_t)      sym("libc.so", "clock_gettime");

    if (!real_prop_get || !real_access || !real_stat || !real_cgt) {
        LOGE("Failed to resolve libc symbols — aborting hooks");
        return;
    }

    /* 3. Патчим */
    install_hook((void*)real_prop_get, (void*)hook_prop_get);
    install_hook((void*)real_access,   (void*)hook_access);
    install_hook((void*)real_stat,     (void*)hook_stat);
    install_hook((void*)real_stat64,   (void*)hook_stat64);
    install_hook((void*)real_cgt,      (void*)hook_clock_gettime);

    /* 4. Поток синхронизации времени (SpeedHackDetector bypass) */
    pthread_t tid;
    pthread_create(&tid, NULL, time_sync_thread, NULL);
    pthread_detach(tid);

    LOGI("=== Bypass ready ===");
}

/* ═══════════════════════════════════════════════════════════════
 *  §12  JNI_OnLoad  — JVM hook-точки
 * ═══════════════════════════════════════════════════════════════ */

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved)
{
    (void)reserved;
    g_jvm = vm;
    JNIEnv *env = get_env();
    if (env) spoof_play_integrity(env);
    return JNI_VERSION_1_6;
}

/* ═══════════════════════════════════════════════════════════════
 *  §13  JNI API  (вызывается из Java MemoryReaderService)
 * ═══════════════════════════════════════════════════════════════ */

/* Читает байты из памяти pid */
JNIEXPORT jbyteArray JNICALL
Java_com_oxide_cheat_MemoryReaderService_readMemoryArray(
        JNIEnv *env, jobject thiz,
        jint pid, jlong addr, jint size)
{
    (void)thiz;
    if (size <= 0 || size > 4*1024*1024) return NULL;
    jbyteArray arr = (*env)->NewByteArray(env, size);
    if (!arr) return NULL;
    void *buf = malloc((size_t)size);
    if (!buf) return NULL;
    ssize_t n = _vm_read((pid_t)pid, buf, (void*)(uintptr_t)addr, (size_t)size);
    if (n > 0) (*env)->SetByteArrayRegion(env, arr, 0, (jint)n, (jbyte*)buf);
    free(buf);
    return arr;
}

/* Базовый адрес модуля */
JNIEXPORT jlong JNICALL
Java_com_oxide_cheat_MemoryReaderService_getModuleBase(
        JNIEnv *env, jobject thiz, jint pid, jstring jname)
{
    (void)thiz;
    const char *n = (*env)->GetStringUTFChars(env, jname, NULL);
    ModInfo mi = find_module((pid_t)pid, n);
    (*env)->ReleaseStringUTFChars(env, jname, n);
    return (jlong)mi.base;
}

/* ELF проверка */
JNIEXPORT jboolean JNICALL
Java_com_oxide_cheat_MemoryReaderService_isValidELF(
        JNIEnv *env, jobject thiz, jint pid, jlong addr)
{
    (void)env; (void)thiz;
    uint32_t magic = 0;
    if (_vm_read((pid_t)pid, &magic, (void*)(uintptr_t)addr, 4) == 4)
        return magic == 0x464C457Fu ? JNI_TRUE : JNI_FALSE;
    return JNI_FALSE;
}

/* Разрешение цепочки указателей */
JNIEXPORT jlong JNICALL
Java_com_oxide_cheat_MemoryReaderService_resolvePointerChain(
        JNIEnv *env, jobject thiz, jint pid, jlong base, jintArray joffs)
{
    (void)thiz;
    jsize  cnt  = (*env)->GetArrayLength(env, joffs);
    jint  *offs = (*env)->GetIntArrayElements(env, joffs, NULL);
    uintptr_t addr = (uintptr_t)base;
    for (jsize i = 0; i < cnt - 1; i++) {
        uintptr_t ptr = 0;
        if (_vm_read((pid_t)pid, &ptr, (void*)(addr + offs[i]), sizeof(ptr)) < 0) {
            addr = 0; break;
        }
        addr = ptr;
        if (!addr) break;
    }
    if (addr && cnt > 0) addr += offs[cnt-1];
    (*env)->ReleaseIntArrayElements(env, joffs, offs, JNI_ABORT);
    return (jlong)addr;
}

/* Совместимость */
JNIEXPORT jint JNICALL
Java_com_oxide_cheat_MemoryReaderService_processVmReadv(
        JNIEnv *env, jobject thiz, jint pid, jlong la, jlong ra, jint size)
{
    (void)env; (void)thiz; (void)la;
    void *buf = malloc((size_t)size);
    if (!buf) return -1;
    ssize_t n = _vm_read((pid_t)pid, buf, (void*)(uintptr_t)ra, (size_t)size);
    free(buf);
    return (jint)n;
}

/* Адрес символа */
JNIEXPORT jlong JNICALL
Java_com_oxide_cheat_MemoryReaderService_getSymbolAddress(
        JNIEnv *env, jobject thiz, jstring jsym)
{
    (void)thiz;
    const char *s = (*env)->GetStringUTFChars(env, jsym, NULL);
    void *a = dlsym(RTLD_DEFAULT, s);
    (*env)->ReleaseStringUTFChars(env, jsym, s);
    return (jlong)(uintptr_t)a;
}

/* /proc/pid/status с пропатченным TracerPid */
JNIEXPORT jstring JNICALL
Java_com_oxide_cheat_MemoryReaderService_getProcessInfo(
        JNIEnv *env, jobject thiz, jint pid)
{
    (void)thiz;
    char path[64], buf[4096];
    snprintf(path, sizeof(path), "/proc/%d/status", pid);
    int fd = open(path, O_RDONLY); if (fd < 0) return (*env)->NewStringUTF(env, "err");
    ssize_t n = read(fd, buf, sizeof(buf)-1); close(fd);
    if (n < 0) return (*env)->NewStringUTF(env, "err");
    buf[n] = '\0';
    patch_status_buf(buf, n);
    return (*env)->NewStringUTF(env, buf);
}

/* Лог */
JNIEXPORT void JNICALL
Java_com_oxide_cheat_MemoryReaderService_nativeLog(
        JNIEnv *env, jobject thiz, jstring jmsg)
{
    (void)thiz;
    const char *m = (*env)->GetStringUTFChars(env, jmsg, NULL);
    LOGD("%s", m);
    (*env)->ReleaseStringUTFChars(env, jmsg, m);
}

/* ─── ID Spoofing API (для Java SpoofManager) ─────────────────── */

JNIEXPORT jstring JNICALL
Java_com_oxide_cheat_SpoofManager_getAndroidId(JNIEnv *env, jclass c)
{
    (void)c; return (*env)->NewStringUTF(env, spoofed_android_id);
}

JNIEXPORT jstring JNICALL
Java_com_oxide_cheat_SpoofManager_getGaid(JNIEnv *env, jclass c)
{
    (void)c; return (*env)->NewStringUTF(env, spoofed_gaid);
}

JNIEXPORT jstring JNICALL
Java_com_oxide_cheat_SpoofManager_getSerial(JNIEnv *env, jclass c)
{
    (void)c; return (*env)->NewStringUTF(env, spoofed_serial);
}

JNIEXPORT jstring JNICALL
Java_com_oxide_cheat_SpoofManager_getImei(JNIEnv *env, jclass c)
{
    (void)c; return (*env)->NewStringUTF(env, spoofed_imei);
}

JNIEXPORT jstring JNICALL
Java_com_oxide_cheat_SpoofManager_getDeviceId(JNIEnv *env, jclass c)
{
    (void)c; return (*env)->NewStringUTF(env, spoofed_device_id);
}

JNIEXPORT jstring JNICALL
Java_com_oxide_cheat_SpoofManager_getSpoofedBuild(JNIEnv *env, jclass c)
{
    (void)c;
    char out[256];
    snprintf(out, sizeof(out),
             "samsung/SM-S918B/dm3q:14/UP1A.231005.007/S918BXXS3CXA1:user/release-keys");
    return (*env)->NewStringUTF(env, out);
}
