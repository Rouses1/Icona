#!/bin/bash
# ═══════════════════════════════════════════════════════
#  OxideCheat - скрипт сборки APK
#  Запускать на Linux/Mac с установленным Android SDK
# ═══════════════════════════════════════════════════════

set -e

echo "╔════════════════════════════════╗"
echo "║     OxideCheat Builder v1.0    ║"
echo "╚════════════════════════════════╝"

# Проверяем Java
if ! command -v java &>/dev/null; then
    echo "[ERROR] Java не найдена. Установите JDK 11+"
    exit 1
fi
echo "[OK] Java: $(java -version 2>&1 | head -1)"

# Даём права gradlew
chmod +x gradlew 2>/dev/null || true

# Собираем debug версию
echo ""
echo "[BUILD] Компиляция debug APK..."
./gradlew assembleDebug 2>&1 | tail -20

APK="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
    echo ""
    echo "╔════════════════════════════════╗"
    echo "║  ✓ APK готов!                 ║"
    echo "╚════════════════════════════════╝"
    echo "Путь: $APK"
    echo "Размер: $(du -h "$APK" | cut -f1)"
    
    # Устанавливаем если есть устройство
    if command -v adb &>/dev/null; then
        DEVICE=$(adb devices | grep -v "List" | grep "device$" | head -1)
        if [ -n "$DEVICE" ]; then
            echo ""
            echo "[ADB] Устанавливаем на устройство..."
            adb install -r "$APK" && echo "[OK] Установлено!"
        fi
    fi
else
    echo "[ERROR] APK не найден. Смотрите ошибки выше."
    exit 1
fi
